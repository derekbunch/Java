/**
 * Created by ijr5 on 2/17/2016.
 */
public class Customer {
    private String name, address, phone;

    public Customer(){

    }

    public String getName() {
        return name;
    }

    public void setName(String n) {
        name = n;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String a) {
        address = a;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String p) {
        phone = p;
    }
}
