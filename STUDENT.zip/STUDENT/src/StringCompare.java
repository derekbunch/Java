/**
 * Created by ijr5 on 1/27/2016.
 */
public class StringCompare {
    public static void main(String[] args) {
        String name1 = "Mark", name2 = "mark", name3 = "Mary";

        if (name1.equalsIgnoreCase(name2)){
            System.out.println("They are the same");
        }



    }
}
