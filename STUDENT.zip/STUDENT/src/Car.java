/**
 * Created by ijr5 on 2/17/2016.
 */
public class Car {
    private String make, model;
    private int year;

    public Car(){

    }
    public String getMake() {
        return make;
    }

    public void setMake(String ma) {
        make = ma;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String mo) {
        model = mo;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int y) {
        year = y;
    }
}
