/**
 * Created by ijr5 on 2/17/2016.
 */
public class ServiceQuote {
    private double partsCharges, laborCharges;

    public double getPartsCharges() {
        return partsCharges;
    }

    public void setPartsCharges(double p) {
        partsCharges = p;
    }

    public double getLaborCharges() {
        return laborCharges;
    }

    public void setLaborCharges(double l) {
        laborCharges = l;
    }

    public double getSalesTax(){
        return ;
    }

    public double getTotalCharges(){
        return totalCharges;
    }

}
