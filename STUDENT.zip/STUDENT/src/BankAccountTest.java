/**
 * Created by ijr5 on 2/17/2016.
 */
public class BankAccountTest {
    public static void main(String[] args) {

        BankAccount myAccount1 = new BankAccount();

        BankAccount myAccount2 = new BankAccount(22.56);

        BankAccount myAccount3 = new BankAccount("22.00");








    }
}
