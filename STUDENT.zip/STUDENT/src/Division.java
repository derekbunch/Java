/**
 * Created by ijr5 on 1/27/2016.
 */
public class Division {
    public static void main(String[] args) {

        double result = 10.0/6.0;
        System.out.printf("The result is %.2f result", result);
        /* .2 is the number of decimal spaces displayed
        */
    }
}
