/**
 * Created by ijr5 on 1/20/2016.
 */
public class SystemTest {
    public static void main(String[] args) {
        System.out.println("Welcome back students!!!");
    }
}
