/**
 * Created by dab137 on 3/28/2016.
 */
public interface Animal {
    //public String picture, food, boundaries;

}
