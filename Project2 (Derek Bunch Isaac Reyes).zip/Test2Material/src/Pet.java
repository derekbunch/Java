/**
 * Created by dab137 on 3/28/2016.
 */
public interface Pet {
    public abstract void beFriendly();
    public abstract void play();
}
