
/**
 * Created by dab137 on 3/23/2016.
 */
public class Cube extends Rectangle {
    private double  height;

    Rectangle object = new Rectangle();

    public Cube(double len, double w, double h) {
        h = height;
        len = object.getLength();
        w = object.getWidth();
    }

    public double getHeight() {
        return height;
    }
    /*
    public double getSurfaceArea(){
        return
    }

    public double getVolume(){
        return
    }
    */
}
