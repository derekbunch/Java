import javax.swing.*;

/**
 * Created by dab137 on 4/13/2016.
 */
public class ShowWindowSpring2016 {
    public static void main(String[] args) {
        JFrame myFirstWindow = new JFrame();
        myFirstWindow.setTitle("A Simple Window");
        myFirstWindow.setSize(350, 250);
        myFirstWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFirstWindow.setVisible(true);


    }
}
