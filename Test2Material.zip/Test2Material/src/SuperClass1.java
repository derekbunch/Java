/**
 * Created by dab137 on 3/23/2016.
 */
public class SuperClass1 {
    public SuperClass1(){
        System.out.println("This is the superclass1 constructor with no arguments");
    }

    public SuperClass1(int arg){
        System.out.println("The following arument was passed to this constructor" + arg);
    }
}
