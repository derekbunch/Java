/**
 * Created by dab137 on 3/23/2016.
 */
public class SubClass1 extends SuperClass1 {
    public SubClass1(){
        super(5);
        System.out.println("This  is the subclass1 constructor");
    }
}
