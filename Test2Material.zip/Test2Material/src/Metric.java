/**
 * Created by dab137 on 3/7/2016.
 */
public class Metric {

    public static double milesToKm(double m){
        return m*1.609;
    }

    public static double KilometersToM(double k){
        return k/1.609;
    }



}
