/**
 * Created by dab137 on 3/23/2016.
 */
public class ConstructorDemo {
    public static void main(String[] args) {

        SubClass1 object = new SubClass1();
        SuperClass1 object2 = new SuperClass1();

    }
}
